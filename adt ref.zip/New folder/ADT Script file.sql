-- Drop existing objects
DROP TABLE borrowed_media;
DROP TABLE media;
DROP TABLE book;
DROP TABLE dvd;
DROP TABLE library_user;
DROP TYPE media_type;
DROP TYPE user_type;
DROP PROCEDURE checkout_media;
DROP PROCEDURE return_media;
DROP PROCEDURE add_media;
DROP PROCEDURE remove_media;

-- Create user-defined types
CREATE OR REPLACE TYPE media_type AS OBJECT (
  id INT,
  title VARCHAR2(255),
  release_date DATE,
  MEMBER FUNCTION play RETURN VARCHAR2,
  MEMBER FUNCTION stop RETURN VARCHAR2
);

CREATE OR REPLACE TYPE user_type AS OBJECT (
  user_id INT,
  name VARCHAR2(255),
  email VARCHAR2(255),
  MEMBER FUNCTION borrow_media RETURN VARCHAR2
);

-- Create tables
CREATE TABLE library_user OF user_type (
  user_id PRIMARY KEY
);

CREATE TABLE media OF media_type (
  id PRIMARY KEY,
  TYPE IS media_type,
  CHECK (TYPE IS NOT NULL)
);

CREATE TABLE book OF media_type (
  author VARCHAR2(255),
  isbn VARCHAR2(20),
  PRIMARY KEY (id),
  FOREIGN KEY (id) REFERENCES media(id)
);

CREATE TABLE dvd OF media_type (
  director VARCHAR2(255),
  duration INT,
  PRIMARY KEY (id),
  FOREIGN KEY (id) REFERENCES media(id)
);

CREATE TABLE borrowed_media (
  user_id INT,
  media_id INT,
  checkout_date DATE,
  return_date DATE,
  PRIMARY KEY (user_id, media_id),
  FOREIGN KEY (user_id) REFERENCES library_user(user_id),
  FOREIGN KEY (media_id) REFERENCES media(id)
);

-- Create stored procedures
CREATE OR REPLACE PROCEDURE checkout_media (
  p_user_id INT,
  p_media_id INT
) AS
BEGIN
  INSERT INTO borrowed_media (user_id, media_id, checkout_date)
  VALUES (p_user_id, p_media_id, SYSDATE);
END checkout_media;

CREATE OR REPLACE PROCEDURE return_media (
  p_user_id INT,
  p_media_id INT
) AS
BEGIN
  UPDATE borrowed_media
  SET return_date = SYSDATE
  WHERE user_id = p_user_id AND media_id = p_media_id;
END return_media;

CREATE OR REPLACE PROCEDURE add_media (
  p_id INT,
  p_title VARCHAR2,
  p_release_date DATE
) AS
BEGIN
  INSERT INTO media (id, title, release_date)
  VALUES (p_id, p_title, p_release_date);
END add_media;

CREATE OR REPLACE PROCEDURE remove_media (
  p_media_id INT
) AS
BEGIN
  DELETE FROM media WHERE id = p_media_id;
END remove_media;

-- Insert sample data
INSERT INTO library_user VALUES (1, 'John Doe', 'john.doe@example.com');
INSERT INTO library_user VALUES (2, 'Jane Smith', 'jane.smith@example.com');

EXEC add_media(1, 'The Great Gatsby', TO_DATE('01-Jan-2000', 'DD-Mon-YYYY'));
EXEC add_media(2, 'Inception', TO_DATE('01-Jan-2010', 'DD-Mon-YYYY'));

INSERT INTO book VALUES (1, 'F. Scott Fitzgerald', '123456789');
INSERT INTO dvd VALUES (2, 'Christopher Nolan', 150);

-- Commit changes
COMMIT;
