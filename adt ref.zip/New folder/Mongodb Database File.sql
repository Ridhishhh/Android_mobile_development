// Create or switch to the database
use your_database_name;

// Create a collection for users
db.createCollection("users");

// Insert documents into the users collection
db.users.insert([
  {
    _id: 1,
    username: "john_doe",
    email: "john@example.com",
    profile: {
      firstName: "John",
      lastName: "Doe",
      age: 30,
      address: {
        city: "New York",
        country: "USA"
      }
    },
    posts: [
      {
        title: "First Post",
        content: "This is the content of the first post.",
        createdAt: ISODate("2023-01-01T12:00:00Z")
      },
      {
        title: "Second Post",
        content: "Content of the second post.",
        createdAt: ISODate("2023-02-15T08:30:00Z")
      }
    ]
  },
  // Add more user documents as needed
]);

// Create a collection for products
db.createCollection("products");

// Insert documents into the products collection
db.products.insert([
  {
    _id: 101,
    name: "Laptop",
    brand: "Dell",
    price: 1200.00,
    specifications: {
      processor: "Intel i7",
      memory: "16GB",
      storage: "512GB SSD"
    },
    reviews: [
      {
        username: "alice",
        rating: 4,
        comment: "Good laptop for work."
      },
      {
        username: "bob",
        rating: 5,
        comment: "Excellent performance."
      }
    ]
  },
  // Add more product documents as needed
]);

// Add more collections and documents based on your design

// Ensure the script is saved with a .js extension, e.g., create_database.js
